#pragma once

#include "yType.hpp"
uint32_t getLcdID(void);
