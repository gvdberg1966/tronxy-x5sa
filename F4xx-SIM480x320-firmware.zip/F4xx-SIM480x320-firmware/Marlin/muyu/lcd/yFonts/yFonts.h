#pragma once
#include "yType.hpp"

//Courier,FixedSys,Terminal,宋体
extern const PicAttr Font_En1020;
extern const PicAttr Font_U16x16Song;
