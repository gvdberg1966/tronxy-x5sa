#pragma once

#include "ySca_s.h"

extern PicAttr picPage;

